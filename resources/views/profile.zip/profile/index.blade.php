@extends('layout.header')
@section('css')
<link rel="stylesheet" type="text/css" href="{{asset('/app-assets/css/colors.css')}}">
<link rel="stylesheet" type="text/css" href="{{asset('/app-assets/css/pages/page-profile.css')}}">
<link rel="stylesheet" type="text/css" href="{{asset('/app-assets/css/plugins/extensions/ext-component-sweet-alerts.css')}}">
@endsection
@section('content')
@section('breadcrumb')
<h2 class="content-header-title float-left mb-0">Profile</h2>
<div class="breadcrumb-wrapper">
    <ol class="breadcrumb">
        <li class="breadcrumb-item"><a href="{{url('/userprofile')}}">Profile</a>
        </li>
        <li class="breadcrumb-item"><a href="#">{{$data['users']->name}}</a>
        </li>
    </ol>
</div>
@endsection
<div class="content-body">
                <div id="user-profile">
                    <!-- profile header -->
                    <div class="row">
                        <div class="col-12">
                            <div class="card profile-header mb-2">
                                <!-- profile cover photo -->
                                <img class="card-img-top" src="../../../app-assets/images/profile/user-uploads/timeline.jpg" alt="User Profile Image" />
                                <!--/ profile cover photo -->

                                <div class="position-relative">
                                    <!-- profile picture -->
                                    <div class="profile-img-container d-flex align-items-center">
                                        <div class="profile-img">
                                            <img src="{{$data['users']->dp}}" class="rounded img-fluid" alt="Card image" />
                                        </div>
                                        <!-- profile title -->
                                        <div class="profile-title ml-3">
                                            <h2 class="text-white">{{$data['users']->name}}</h2>
                                            <p class="text-white">{{$data['users']->role->role_title}}</p>
                                        </div>
                                    </div>
                                </div>

                                <!-- tabs pill -->
                                <div class="profile-header-nav">
                                    <!-- navbar -->
                                    <nav class="navbar navbar-expand-md navbar-light justify-content-end justify-content-md-between w-100">
                                        <button class="btn btn-icon navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                                            <i data-feather="align-justify" class="font-medium-5"></i>
                                        </button>

                                        <!-- collapse  -->
                                        <div class="collapse navbar-collapse" id="navbarSupportedContent">
                                            <div class="profile-tabs d-flex justify-content-between flex-wrap mt-1 mt-md-0">
                                                <ul class="nav nav-pills mb-0">
                                                    <li class="nav-item">
                                                        <a class="nav-link font-weight-bold active" href="javascript:void(0)">
                                                            <span class="d-none d-md-block">Feed</span>
                                                            <i data-feather="rss" class="d-block d-md-none"></i>
                                                        </a>
                                                    </li>
                                                    <li class="nav-item">
                                                        <a class="nav-link font-weight-bold" href="javascript:void(0)">
                                                            <span class="d-none d-md-block">About</span>
                                                            <i data-feather="info" class="d-block d-md-none"></i>
                                                        </a>
                                                    </li>
                                                    <li class="nav-item">
                                                        <a class="nav-link font-weight-bold" href="javascript:void(0)">
                                                            <span class="d-none d-md-block">Photos</span>
                                                            <i data-feather="image" class="d-block d-md-none"></i>
                                                        </a>
                                                    </li>
                                                    <li class="nav-item">
                                                        <a class="nav-link font-weight-bold" href="javascript:void(0)">
                                                            <span class="d-none d-md-block">Friends</span>
                                                            <i data-feather="users" class="d-block d-md-none"></i>
                                                        </a>
                                                    </li>
                                                </ul>
                                                <!-- edit button -->
                                                <button class="btn btn-primary">
                                                    <i data-feather="edit" class="d-block d-md-none"></i>
                                                    <span class="font-weight-bold d-none d-md-block">Edit</span>
                                                </button>
                                            </div>
                                        </div>
                                        <!--/ collapse  -->
                                    </nav>
                                    <!--/ navbar -->
                                </div>
                            </div>
                        </div>
                    </div>
                    <!--/ profile header -->

                    <!-- profile info section -->
                    <section id="profile-info">
                        <div class="row">
                            <!-- left profile info section -->
                            <div class="col-lg-3 col-12 order-2 order-lg-1">
                                <!-- about -->
                                <div class="card">
                                    <div class="card-body">
                                        <h5 class="mb-75">About</h5>
                                        <p class="card-text">
                                            Tart I love sugar plum I love oat cake. Sweet ⭐️ roll caramels I love jujubes. Topping cake wafer.
                                        </p>
                                        <div class="mt-2">
                                            <h5 class="mb-75">Joined:</h5>
                                            <p class="card-text">November 15, 2015</p>
                                        </div>
                                        <div class="mt-2">
                                            <h5 class="mb-75">Lives:</h5>
                                            <p class="card-text">New York, USA</p>
                                        </div>
                                        <div class="mt-2">
                                            <h5 class="mb-75">Email:</h5>
                                            <p class="card-text">bucketful@fiendhead.org</p>
                                        </div>
                                        <div class="mt-2">
                                            <h5 class="mb-50">Website:</h5>
                                            <p class="card-text mb-0">www.pixinvent.com</p>
                                        </div>
                                    </div>
                                </div>
                                <!--/ about -->

                                <!-- suggestion pages -->
                                <div class="card">
                                    <div class="card-body profile-suggestion">
                                        <h5 class="mb-2">Suggested Pages</h5>
                                        <!-- user suggestions -->
                                        <div class="d-flex justify-content-start align-items-center mb-1">
                                            <div class="avatar mr-1">
                                                <img src="../../../app-assets/images/avatars/12-small.png" alt="avatar img" height="40" width="40" />
                                            </div>
                                            <div class="profile-user-info">
                                                <h6 class="mb-0">Peter Reed</h6>
                                                <small class="text-muted">Company</small>
                                            </div>
                                            <div class="profile-star ml-auto"><i data-feather="star" class="font-medium-3"></i></div>
                                        </div>
                                        <!-- user suggestions -->
                                        <div class="d-flex justify-content-start align-items-center mb-1">
                                            <div class="avatar mr-1">
                                                <img src="../../../app-assets/images/avatars/1-small.png" alt="avatar" height="40" width="40" />
                                            </div>
                                            <div class="profile-user-info">
                                                <h6 class="mb-0">Harriett Adkins</h6>
                                                <small class="text-muted">Company</small>
                                            </div>
                                            <div class="profile-star ml-auto"><i data-feather="star" class="font-medium-3"></i></div>
                                        </div>
                                        <!-- user suggestions -->
                                        <div class="d-flex justify-content-start align-items-center mb-1">
                                            <div class="avatar mr-1">
                                                <img src="../../../app-assets/images/avatars/10-small.png" alt="avatar" height="40" width="40" />
                                            </div>
                                            <div class="profile-user-info">
                                                <h6 class="mb-0">Juan Weaver</h6>
                                                <small class="text-muted">Company</small>
                                            </div>
                                            <div class="profile-star ml-auto"><i data-feather="star" class="font-medium-3"></i></div>
                                        </div>
                                        <!-- user suggestions -->
                                        <div class="d-flex justify-content-start align-items-center mb-1">
                                            <div class="avatar mr-1">
                                                <img src="../../../app-assets/images/avatars/3-small.png" alt="avatar img" height="40" width="40" />
                                            </div>
                                            <div class="profile-user-info">
                                                <h6 class="mb-0">Claudia Chandler</h6>
                                                <small class="text-muted">Company</small>
                                            </div>
                                            <div class="profile-star ml-auto"><i data-feather="star" class="font-medium-3"></i></div>
                                        </div>
                                        <!-- user suggestions -->
                                        <div class="d-flex justify-content-start align-items-center mb-1">
                                            <div class="avatar mr-1">
                                                <img src="../../../app-assets/images/avatars/5-small.png" alt="avatar img" height="40" width="40" />
                                            </div>
                                            <div class="profile-user-info">
                                                <h6 class="mb-0">Earl Briggs</h6>
                                                <small class="text-muted">Company</small>
                                            </div>
                                            <div class="profile-star ml-auto">
                                                <i data-feather="star" class="profile-favorite font-medium-3"></i>
                                            </div>
                                        </div>
                                        <!-- user suggestions -->
                                        <div class="d-flex justify-content-start align-items-center">
                                            <div class="avatar mr-1">
                                                <img src="../../../app-assets/images/avatars/6-small.png" alt="avatar img" height="40" width="40" />
                                            </div>
                                            <div class="profile-user-info">
                                                <h6 class="mb-0">Jonathan Lyons</h6>
                                                <small class="text-muted">Beauty Store</small>
                                            </div>
                                            <div class="profile-star ml-auto"><i data-feather="star" class="font-medium-3"></i></div>
                                        </div>
                                    </div>
                                </div>
                                <!--/ suggestion pages -->
                            </div>
                            <!--/ left profile info section -->

                            <!-- center profile info section -->
                            <div class="col-lg-6 col-12 order-1 order-lg-2">
                                <!-- post 1 -->
                               @foreach ($data['training'] as $value)
                                    {{-- expr --}}
                              
                                <div class="card">
                                    <div class="card-body">
                                        <div class="d-flex justify-content-start align-items-center mb-1">
                                            <!-- avatar -->
                                            <div class="avatar mr-1">
                                                <img src="{{$data['users']->dp}}" alt="avatar img" height="50" width="50" />
                                            </div>
                                            <!--/ avatar -->
                                            <div class="profile-user-info">
                                                <h6 class="mb-0">{{$value->title}}</h6>
                                                <small class="text-muted">{{$value->created_at->format('Y-m-d H:i A') }}</small>
                                            </div>
                                        </div>
                                        <p class="card-text">
                                            {{$value->description}}
                                        </p>
                                        <!-- post img -->
                                        @if ($value->type=='video')
                                             <iframe src="{{$value->file_upload}}" class="w-100 rounded border-0 height-250 mb-50"></iframe>
                                        @else
                                            <img class="img-fluid rounded mb-75" src="{{$value->file_upload}}" alt="avatar img" />   
                                        @endif
                                        

                                      
                                        <!--/ post img -->

                                        <!-- like share -->
                                        <div class="row d-flex justify-content-start align-items-center flex-wrap pb-50">
                                            <div class="col-sm-6 d-flex justify-content-between justify-content-sm-start mb-2">
                                                <a href="javascript:void(0)" class="d-flex align-items-center text-muted text-nowrap">
                                                    <i data-feather="heart" class="profile-likes font-medium-3 mr-50"></i>
                                                   
                                                    <span>{{$value->user_like}}</span>
                                                   
                                                </a>

                                                <!-- avatar group with tooltip -->
                                                <div class="d-flex align-items-center">
                                                    <div class="avatar-group ml-1">
                                                        @foreach($value->likes as $key3=>$value3)  
                                                        <div data-toggle="tooltip" data-popup="tooltip-custom" data-placement="bottom" data-original-title="{{$value3->user->name}}" class="avatar pull-up">
                                                            <img src="{{$value3->user->dp}}" alt="Avatar" height="26" width="26" />
                                                        </div>
                                                        @endforeach
                                                     
                                                      
                                                    </div>
                                                 
                                                    <a href="javascript:void(0)" class="text-muted text-nowrap ml-50">{{$value->total_like}}</a>
                                                </div>
                                                <!-- avatar group with tooltip -->
                                            </div>

                                            <!-- share and like count and icons -->
                                            <div class="col-sm-6 d-flex justify-content-between justify-content-sm-end align-items-center mb-2">
                                                <a href="javascript:void(0)" class="text-nowrap">
                                                    <i data-feather="message-square" class="text-body font-medium-3 mr-50"></i>
                                                    <span class="text-muted mr-1">{{count($value->comments)}}</span>
                                                </a>                                               
                                            </div>
                                            <!-- share and like count and icons -->
                                        </div>
                                        <!-- like share -->

                                        <!-- comments -->
                                        @foreach($value->comments as $key2=>$value2)
                                        <div class="d-flex align-items-start mb-1">
                                            <div class="avatar mt-25 mr-75">
                                                <img src="{{$value2->user->dp}}" alt="Avatar" height="34" width="34" />
                                            </div>
                                            <div class="profile-user-info w-100">
                                                <div class="d-flex align-items-center justify-content-between">
                                                    <h6 class="mb-0">{{$value2->user->name}}</h6>
                                                    <a href="javascript:void(0)">
                                                        <i data-feather="heart" class="text-body font-medium-3"></i>
                                                        <span class="align-middle text-muted">34</span>
                                                    </a>
                                                </div>
                                                <small>{{$value2->comment}}</small>
                                            </div>
                                        </div>
                                        @endforeach
                                        <!--/ comments -->

                                        <!-- comment box -->
                                        <fieldset class="form-label-group mb-75 d-none">
                                            <textarea class="form-control" id="label-textarea" rows="3" placeholder="Add Comment"></textarea>
                                            <label for="label-textarea">Add Comment</label>
                                        </fieldset>
                                        <!--/ comment box -->
                                        <button type="button" class="btn btn-sm btn-primary d-none">Post Comment</button>
                                    </div>
                                </div>
                                  @endforeach 
                                <!--/ post 1 -->

                               
                            </div>
                            <!--/ center profile info section -->

                            <!-- right profile info section -->
                            <div class="col-lg-3 col-12 order-3">
                                <!-- latest profile pictures -->
                                <div class="card">
                                    <div class="card-body">
                                        <h5 class="mb-0">Latest Photos</h5>
                                        <div class="row">
                                         @foreach($data['training'] as $key4=>$value4)  
                                            <div class="col-md-4 col-6 profile-latest-img">
                                                <a href="javascript:void(0)">
                                                    <img src="{{$value4->file_upload}}" class="img-fluid rounded" alt="avatar img"/>
                                                </a>
                                            </div>
                                          @endforeach                                   
                                        </div>
                                    </div>
                                </div>
                                <!--/ latest profile pictures -->


                            </div>
                            <!--/ right profile info section -->
                        </div>

                        <!-- reload button -->
                        <div class="row">
                            <div class="col-12 text-center">
                                <button type="button" class="btn btn-sm btn-primary block-element border-0 mb-1">Load More</button>
                            </div>
                        </div>
                        <!--/ reload button -->
                    </section>
                    <!--/ profile info section -->
                </div>

            </div>
@endsection

@section('js')
<link rel="stylesheet" type="text/css" href="{{asset('/app-assets/vendors/js/extensions/sweetalert2.all.min.js')}}">
<link rel="stylesheet" type="text/css" href="{{asset('/app-assets/js/scripts/pages/page-profile.js')}}">

@endsection